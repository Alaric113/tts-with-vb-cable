# updater.py
import sys
import os
import time
import subprocess

def main():
    """
    這個腳本由主程式啟動，用於執行更新操作。
    它會接收三個命令列參數：
    1. '--run-updater' 旗標 (sys.argv[1])
    2. 主程式的 PID (Process ID)
    3. 舊的 exe 檔案路徑 (old_exe_path)
    4. 新的 exe 檔案路徑 (new_exe_path)
    """
    if len(sys.argv) != 5: # sys.argv[0] 是 JuMouth.exe
        print("Updater: 參數數量錯誤。")
        input("按 Enter 鍵結束...")
        return

    pid_to_wait = int(sys.argv[2])
    old_exe_path = sys.argv[3]
    new_exe_path = sys.argv[4]

    print(f"Updater: 等待主程式 (PID: {pid_to_wait}) 關閉...")

    # --- 等待主程式完全退出 ---
    # 這是一個比 tasklist 更可靠的方法
    is_running = True
    while is_running:
        try:
            # 在 Windows 上，傳送訊號 0 不會做任何事，但如果程序不存在會引發 OSError
            os.kill(pid_to_wait, 0)
            time.sleep(0.5)
        except OSError:
            # 程序已不存在
            is_running = False
        except Exception:
            # 其他錯誤，也當作程序已結束
            is_running = False

    print("Updater: 主程式已關閉。")
    time.sleep(1) # 額外等待一秒，確保檔案鎖定已釋放

    # --- 執行檔案替換 ---
    try:
        print(f"Updater: 正在替換檔案...\n  刪除: {old_exe_path}\n  移動: {new_exe_path}")
        os.remove(old_exe_path)
        os.rename(new_exe_path, old_exe_path)
        print("Updater: 檔案替換成功。")
    except Exception as e:
        print(f"Updater: 檔案替換失敗: {e}")
        # 即使失敗，仍然嘗試啟動舊的執行檔
        pass

    # --- 在一個完全乾淨的環境中重啟應用程式 ---
    print("Updater: 正在重新啟動應用程式...")
    try:
        # 這是最關鍵的一步：建立一個乾淨的環境變數字典
        clean_env = os.environ.copy()
        # 移除所有 PyInstaller 的暫存變數
        for key in list(clean_env.keys()):
            if key.startswith('_MEI'):
                del clean_env[key]
        
        # 使用 DETACHED_PROCESS 在一個新的 session 中啟動，徹底脫鉤
        subprocess.Popen([old_exe_path],
                         creationflags=subprocess.DETACHED_PROCESS,
                         env=clean_env,
                         close_fds=True)
        print("Updater: 啟動指令已發送。")
    except Exception as e:
        print(f"Updater: 重新啟動失敗: {e}")
        input("按 Enter 鍵結束...")


if __name__ == "__main__":
    # 為了在打包後也能看到日誌，我們將輸出重導向到一個檔案
    log_dir = os.path.dirname(sys.argv[3]) # old_exe_path 的目錄
    log_file = os.path.join(log_dir, "updater.log")
    with open(log_file, "w", encoding="utf-8") as f:
        # 將 stdout 和 stderr 都重導向到檔案
        sys.stdout = f
        sys.stderr = f
        print("--- Updater Log ---")
        main()
        print("--- Updater End ---")
